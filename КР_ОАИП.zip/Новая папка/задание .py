x = str(input())
print(x, sep = '')