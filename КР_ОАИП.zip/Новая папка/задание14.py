x = input()
print(*x, sep = '*')